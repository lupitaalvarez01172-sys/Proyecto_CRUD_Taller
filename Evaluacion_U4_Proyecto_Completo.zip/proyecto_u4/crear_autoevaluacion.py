from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import inch
from reportlab.platypus import (
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)


archivo = "Autoevaluacion_U4.pdf"
documento = SimpleDocTemplate(
    archivo,
    pagesize=letter,
    rightMargin=0.65 * inch,
    leftMargin=0.65 * inch,
    topMargin=0.55 * inch,
    bottomMargin=0.55 * inch,
)

estilos = getSampleStyleSheet()
estilos.add(
    ParagraphStyle(
        name="TituloAzul",
        parent=estilos["Title"],
        fontName="Helvetica-Bold",
        fontSize=18,
        textColor=colors.HexColor("#16324F"),
        alignment=TA_CENTER,
        spaceAfter=14,
    )
)
estilos.add(
    ParagraphStyle(
        name="Celda",
        parent=estilos["BodyText"],
        fontName="Helvetica",
        fontSize=8.5,
        leading=11,
    )
)
estilos.add(
    ParagraphStyle(
        name="CeldaCentro",
        parent=estilos["BodyText"],
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=colors.white,
        alignment=TA_CENTER,
    )
)
estilos.add(
    ParagraphStyle(
        name="Puntaje",
        parent=estilos["BodyText"],
        fontName="Helvetica-Bold",
        fontSize=9,
        textColor=colors.black,
        alignment=TA_CENTER,
    )
)

contenido = [
    Paragraph("Autoevaluación - Unidad 4", estilos["TituloAzul"]),
    Paragraph(
        "<b>Matrícula:</b> ____________________ &nbsp;&nbsp;&nbsp;&nbsp; "
        "<b>Nombre:</b> ________________________________________________",
        estilos["BodyText"],
    ),
    Spacer(1, 14),
]

datos = [
    [
        Paragraph("<b>Criterio</b>", estilos["CeldaCentro"]),
        Paragraph("<b>Autoevaluación</b><br/>(7, 8, 9, 10)", estilos["CeldaCentro"]),
        Paragraph("<b>Motivos</b>", estilos["CeldaCentro"]),
    ],
    [
        Paragraph("Entrega en tiempo y forma (Git)", estilos["Celda"]),
        Paragraph("9", estilos["Puntaje"]),
        Paragraph(
            "El proyecto está completo, organizado por carpetas e incluye documentación. "
            "Solo falta subirlo al repositorio y realizar los commits en la cuenta del alumno.",
            estilos["Celda"],
        ),
    ],
    [
        Paragraph("Pruebas Unitarias (pytest)", estilos["Celda"]),
        Paragraph("10", estilos["Puntaje"]),
        Paragraph(
            "Se incluyeron pruebas para validación, registro, consulta, actualización, "
            "eliminación y duplicados. Siguen el patrón AAA y se ejecutan de forma aislada.",
            estilos["Celda"],
        ),
    ],
    [
        Paragraph("Manejo de Excepciones", estilos["Celda"]),
        Paragraph("10", estilos["Puntaje"]),
        Paragraph(
            "Se crearon excepciones para costos inválidos, servicios inexistentes y "
            "registros duplicados. Las operaciones usan try, except, else y finally.",
            estilos["Celda"],
        ),
    ],
    [
        Paragraph("Debugging con pdb", estilos["Celda"]),
        Paragraph("10", estilos["Puntaje"]),
        Paragraph(
            "Se agregaron puntos de interrupción en la validación y búsqueda en la base "
            "de datos, además de ejemplos con los comandos p, n, s y c.",
            estilos["Celda"],
        ),
    ],
    [
        Paragraph("Proyecto CRUD (Tkinter + MySQL + SOLID)", estilos["Celda"]),
        Paragraph("10", estilos["Puntaje"]),
        Paragraph(
            "El sistema permite registrar, consultar, actualizar y eliminar servicios. "
            "Cuenta con interfaz gráfica, base MySQL, validaciones y clases con "
            "responsabilidades separadas.",
            estilos["Celda"],
        ),
    ],
]

tabla = Table(datos, colWidths=[1.62 * inch, 1.05 * inch, 4.53 * inch], repeatRows=1)
tabla.setStyle(
    TableStyle(
        [
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#16324F")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("BACKGROUND", (0, 1), (-1, -1), colors.HexColor("#F4F7FA")),
            ("GRID", (0, 0), (-1, -1), 0.6, colors.HexColor("#9AA9B8")),
            ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ("ALIGN", (1, 1), (1, -1), "CENTER"),
            ("LEFTPADDING", (0, 0), (-1, -1), 7),
            ("RIGHTPADDING", (0, 0), (-1, -1), 7),
            ("TOPPADDING", (0, 0), (-1, -1), 8),
            ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ]
    )
)
contenido.append(tabla)
contenido.extend(
    [
        Spacer(1, 14),
        Paragraph(
            "<b>Promedio de autoevaluación:</b> 9.8",
            ParagraphStyle(
                "Promedio",
                parent=estilos["Heading2"],
                textColor=colors.HexColor("#16324F"),
                alignment=TA_CENTER,
            ),
        ),
        Spacer(1, 8),
        Paragraph(
            "Nota: antes de entregar, escribe tu matrícula y nombre, sube el proyecto "
            "a Git y, si ya hiciste los commits, puedes cambiar la primera calificación a 10.",
            estilos["Celda"],
        ),
    ]
)

documento.build(contenido)
print(archivo)
